## -----------------------------------------------------------------------------

# "C:/Users/user1/Documents/Analysis/data", the directory

# containing IDAT files and \# Sample_Sheet.csv

# library(EpigeneticAgePipeline)

# main(directory = "C:/Users/user1/Documents/Analysis/data",
# normalize=,
# useBeta=, arrayType=,
# generateResiduals=,
# useSampleSheet=)


## -----------------------------------------------------------------------------
# library(EpigeneticAgePipeline

# main(directory = "C:/Users/user1/Documents/Analysis/data", 
# normalize= TRUE, 
# useBeta=, 
# arrayType=, 
# generateResiduals=, 
# useSampleSheet=)

## -----------------------------------------------------------------------------
# library(EpigeneticAgePipeline)

# main(directory = "C:/Users/user1/Documents/Analysis/data", 
# normalize= TRUE, 
# useBeta= FALSE, 
# arrayType=, 
# generateResiduals=, 
# useSampleSheet=)

## -----------------------------------------------------------------------------
# library(EpigeneticAgePipeline)

# main(directory = "C:/Users/user1/Documents/Analysis/data", 
# normalize= TRUE, 
# useBeta= FALSE, 
# arrayType="450K", 
# generateResiduals=, 
# useSampleSheet=)

#make sure to use a capital K

## -----------------------------------------------------------------------------
# library(EpigeneticAgePipeline)

# main(directory = "C:/Users/user1/Documents/Analysis/data", 
# normalize= TRUE, 
# useBeta= FALSE, 
# arrayType="450K", 
# generateResiduals= TRUE, 
# useSampleSheet=)

#NOTE: the variables that will be adjusted for are provided during runtime

## -----------------------------------------------------------------------------
# library(EpigeneticAgePipeline)

# main(directory = "C:/Users/user1/Documents/Analysis/data", 
# normalize= TRUE, 
# useBeta= FALSE, 
# arrayType="450K", 
# generateResiduals= TRUE, 
# useSampleSheet=)

## -----------------------------------------------------------------------------
# ?EpigeneticAgePipeline::main

## ----echo=FALSE---------------------------------------------------------------
sessionInfo()

